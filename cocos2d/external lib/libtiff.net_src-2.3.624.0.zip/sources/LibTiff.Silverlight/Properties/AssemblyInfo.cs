﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("BitMiracle.LibTiff.NET for Silverlight")]
[assembly: AssemblyDescription("Silverlight-compatible version of LibTiff library made by Bit Miracle")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Bit Miracle")]
[assembly: AssemblyProduct("BitMiracle.LibTiff.NET for Silverlight")]
[assembly: AssemblyCopyright("Copyright (C) 2008-2011, Bit Miracle")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("b4f8a800-984f-485a-9168-c0fb9b446191")]

[assembly: CLSCompliant(true)]