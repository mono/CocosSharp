Test output will be placed in this folder.
Please do not remove it.