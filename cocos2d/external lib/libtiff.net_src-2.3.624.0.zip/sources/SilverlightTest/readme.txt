This is Silverlight Test Application that shows how read the data bits of Tiff files
and apply them to Silverlight's WriteableBitmap.
    
The code of Silverlight Test Application (along with the changes to library code) is contributed by:
Michael Epner
Developer Future Software GmbH
mepner@futuresoft.de
http://www.futuresoft.de
