﻿namespace UnitTests
{
    static class TestCase
    {
        public static string Folder
        {
            get
            {
                return @"..\..\..\TestCase\";
            }
        }
    }
}
